package com.jczzwt.lampiaocs4;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
public class LampiaoCS4 implements ModInitializer {
 private static final String KEY="lampiao_lendario";
 public void onInitialize(){ ServerTickEvents.END_SERVER_TICK.register(server->{ for(ServerPlayerEntity p:server.getPlayerManager().getPlayerList()){ if(has(p.getMainHandStack())||has(p.getOffHandStack())) p.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY,5,0,false,false,false)); else p.removeStatusEffect(StatusEffects.INVISIBILITY); }}); }
 private boolean has(ItemStack s){ if(s.isEmpty()||!s.isOf(Items.SOUL_LANTERN))return false; NbtComponent d=s.get(DataComponentTypes.CUSTOM_DATA); return d!=null&&d.copyNbt().getBoolean(KEY).orElse(false); }
}
